const mongoose = require ('mongoose');
const studentSchema = mongoose.Schema({
    full_name:{
        type:String,
        required:true,
    },
    age:{
        type:Number,
        required:true,
    },
    sex:{
        type: String,
        required:true,
    },
    final_score:{
        type:Number,
        required:true,   
    },
});

const studentModel = mongoose.model('studentModel', studentSchema);
module.exports = studentModel;